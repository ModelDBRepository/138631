Sigma = 0.045;                     % original
Mean = 0;   % June 19
Noise_SAC_PFC = (randn(Num_SAC_Nodes,1)*Sigma)+ Mean; 
Noise_PFC_Motor = (randn(Num_PFC_Nodes,Num_Motor_Nodes)*Sigma)+ Mean;  
