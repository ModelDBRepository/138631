% this is file is to see whether the model Gates A and make Act2 and 
GateBAct2=zeros (1, NumberOfTrials);

for i=1:NumberOfTrials
    if (IsBGatedGen (i) == 1 & WhatTrialAct2Made(i) == 1)
        GateBAct2 (i) = 1;
    end
end

GateBAct2