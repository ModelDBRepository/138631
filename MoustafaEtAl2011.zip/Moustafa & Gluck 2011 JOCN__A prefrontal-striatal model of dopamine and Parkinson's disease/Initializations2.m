experiment_type = 'A+';  % 
%experiment_type = 'OneCue';  % here, only paying attention to one cue is key for learning the task
%experiment_type = 'OneCue2';  % here, only paying attention to one cue is key for learning the task
%experiment_type = 'Slots';  % only training part
%experiment_type = 'Slots_Rev';  % only training part
%experiment_type = 'Crabs'; 
%experiment_type = 'Crabs_Rev'; 
experiment_type = 'WP';  % weather prediction

if(isequal(experiment_type,'A+'))
    NumTrls (1,1) = 200;  % 300...1300
    NumPhases = 1;
elseif(isequal(experiment_type,'OneCue'))
    NumTrls (1,1) = 1000;  % 300...1300
    NumPhases = 1;
elseif(isequal(experiment_type,'OneCue2'))
    NumTrls (1,1) = 2000;  % 300...1300
    NumPhases = 1;
elseif(isequal(experiment_type,'Slots') | isequal(experiment_type,'Crabs') | isequal(experiment_type,'WP'))
    NumTrls (1,1) = 1000;  % 300...1300
    NumTrls (1,1) = 1400;  % for WP
    NumPhases = 1;
elseif(isequal(experiment_type,'Slots_Rev') | isequal(experiment_type,'Crabs_Rev'))
    NumTrls (1,1) = 1000;  % 300...1300
    NumTrls (1,2) = 1000;  % 300...1300
    NumPhases = 2;
end

NumTimeSteps = 3;  % first one nothing, 2  =  cue, 3 reward

NumTotalTrls = 0;
for i = 1:NumPhases
    NumTotalTrls = NumTotalTrls + NumTrls(1,i);
end

%Num_SAC_Nodes = 3;
Num_SAC_Nodes = 6;
%Num_PFC_Nodes = 3;
Num_PFC_Nodes = 6;
Num_Motor_Nodes = 2;

SAC_Act = zeros(Num_SAC_Nodes,1);
PFC_Act = zeros(Num_PFC_Nodes,1);
Motor_Act = zeros(Num_Motor_Nodes,1);

SAC_Act_time = zeros(Num_SAC_Nodes,NumTimeSteps);
PFC_Act_time = zeros(Num_PFC_Nodes,NumTimeSteps);
Motor_Act_time = zeros(Num_Motor_Nodes,NumTimeSteps);

Wts_SAC_PFC = zeros (Num_SAC_Nodes,1); % because it is 1-1.
Wts_PFC_Motor = zeros (Num_PFC_Nodes,Num_Motor_Nodes); % because it is 1-1.

Wts_SAC_PFC_Perturbed = zeros (Num_SAC_Nodes,1); % because it is 1-1.
Wts_PFC_Motor_Perturbed = zeros (Num_PFC_Nodes,Num_Motor_Nodes); % because it is 1-1.

Wts_SAC_PFC_all = zeros(Num_SAC_Nodes,NumTotalTrls);
Wts_PFC_Motor_all = zeros(Num_PFC_Nodes,Num_Motor_Nodes,NumTotalTrls);

InitialWtsCritic = 0.001;
Wts_SAC_Critic = zeros (Num_SAC_Nodes,1) + InitialWtsCritic;

%====================================================
TDError = zeros(1,NumTimeSteps);
TDError(NumTimeSteps) = 0.1;
%TDError=[0 0 0 0 0 0 0 0 0 0 0.1]; % March 22.  T=1,2,3,...,11. Delay interval 3-9. Cue is presented at time 2. X is presented at time 10. Reward 11.

DiscountFactor=0.99;

Prediction = zeros (1,NumTimeSteps);  % March 22
Reward = zeros (1,NumTimeSteps);   % March 22
InitialWtsCritic = 0.001;    % works

LR_Critic = 0.01;
%*********************************************************************************************
ThresholdMotor = 0.75;
ThresholdPFC = 0.78;

MotorActionMade=0; % this variable is for testing whether an action made or not at time step 6. This varibale takes a value either zero(no motor action is made at time step 6) or from 4-6 (represents making a motor response at time step 6).

NumTrlsRewarded=0;

LR_atten = 0.006;
LR_motor = 0.006;
%***********************************************
InitialWtsActor = 0.5;

%Obs_resp_all = zeros(NumTotalTrls,1);
TDError_all = zeros(NumTotalTrls,NumTimeSteps);
Prediction_all = zeros(NumTotalTrls,NumTimeSteps);
TrlNumTotal = 1;

% TDErrorGen=zeros(NumberOfTrials,NumTimeSteps);  % this should total num of trials...see DLR model part
% %**************************************
% RewardYesNo=zeros(1,NumberOfTrials);      % this variable tells whether a reward was presented or not in each trial. A NEW Variable(Feb. 16, 2005).
% RewardYesNo2=zeros(NumberOfTrials,1);   % Sept 26.

if(isequal(experiment_type,'Slots') | (isequal(experiment_type,'Slots_Rev')))
    NumCases = 8;
    
%     Input_1 = [1 1 1];   % Candle Fish Boat
%     Input_2 = [1 1 0];   %
%     Input_3 = [1 0 1];   %
%     Input_4 = [1 0 0];   %
%     Input_5 = [0 1 1];   %
%     Input_6 = [0 1 0];   %
%     Input_7 = [0 0 1];   %
%     Input_8 = [0 0 0];   %

    Input_1 = [1 1 1 0 0 0];   %A
    Input_2 = [1 1 0 0 0 1];   %A
    Input_3 = [1 0 1 0 1 0];   %A
    Input_4 = [1 0 0 0 1 1];   %B
    Input_5 = [0 1 1 1 0 0];   %A
    Input_6 = [0 1 0 1 0 1];   %B
    Input_7 = [0 0 1 1 1 0];   %B
    Input_8 = [0 0 0 1 1 1];   %B

elseif(isequal(experiment_type,'OneCue'))
    Input_1 = [0 1 1];  
    Input_2 = [1 0 1];  
    NumCases = 2;
elseif(isequal(experiment_type,'OneCue2'))    
    NumCases = 4;
   
    Input_1 = [1 1 0];    % here A is correct
    Input_2 = [1 0 1];    % here A is correct  
    Input_3 = [1 0 0];    % here A is correct
    Input_4 = [0 0 1];    % here B is correct
    % works 100 percent
    
    Input_1 = [1 1 0];    % here A is correct
    Input_2 = [1 0 1];    % here A is correct  
    Input_3 = [1 0 0];    % here A is correct
    Input_4 = [1 1 1];    % here B is correct
    % does not work
    
    Input_1 = [1 1 0];    % here A is correct
    Input_2 = [1 0 1];    % here A is correct  
    Input_3 = [1 0 0];    % here A is correct
    Input_4 = [0 0 1];    % here B is correct. If this is A, it also works. also works if  Input_4 = [0 1 1]
    % works  100 percent
    
    % this is one aspect of Slots
    Input_1 = [1 1 1];   %  A
    Input_2 = [1 1 0];   %  A
    Input_3 = [1 0 1];   %  A
    Input_4 = [1 0 0];   %  B
 
elseif(isequal(experiment_type,'WP'))
    NumCases = 14;
    % A is Sun and B is Rain
    Input_1 = [0 0 0 1 0 0];   %Sun
    Input_2 = [0 0 1 0 0 0];   %Sun
    Input_3 = [0 0 1 1 0 0];   %Sun
    Input_4 = [0 1 0 0 0 0];   %Rain
    Input_5 = [0 1 0 1 0 0];   %Sun
    Input_6 = [0 1 1 0 0 0];   %Sun...can be rain instead
    Input_7 = [0 1 1 1 0 0];   %Sun
    Input_8 = [1 0 0 0 0 0];   %Rain
    Input_9 = [1 0 0 1 0 0];   %Rain ..can be sun instead  
    Input_10 =[1 0 1 0 0 0];   %Rain
    Input_11 =[1 0 1 1 0 0];   %Sun
    Input_12 =[1 1 0 0 0 0];   %Rain
    Input_13 =[1 1 0 1 0 0];   %Rain
    Input_14 =[1 1 1 0 0 0];   %Rain
end




