Program Code for the Prefrontal-Striatal and dopamine Interactions

This is a description of code used in the following paper:
Moustafa, A. A.,& Gluck, M. A. (2011). A neurocomputational model of dopamine
and prefrontal-striatal interactions during multi-cue category learning by Parkinson's patients. Journal of Cognitive Neuroscience.

The code is written using Matlab R2008a software. For any questions, comments,
or bug reports, please contact Ahmed Moustafa at ahmedhalimo@gmail.com

To run the program, use the file RunPro.m. The rest is self-explained.
