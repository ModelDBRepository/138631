% in this file I will see at which trial the model gates a cue and get rewarded at the same time.
%First, I will match GateA with reward and then GateB with reward, then I will merge them.

GatingARewaded = zeros(1, NumberOfTrials);
GatingBRewarded = zeros(1, NumberOfTrials);
GatingRewarded = zeros(1, NumberOfTrials);

% Match GatingA with Reward

for i=1:NumberOfTrials
    if (IsAGatedGen (i) == 1 & RewardYesNo (i) == 1)
        GatingARewarded (i) = 1;
    end
end

% Match GatingB with Reward

for i=1:NumberOfTrials
    if (IsBGatedGen (i) == 1 & RewardYesNo (i) == 1)
        GatingBRewarded (i) = 1;
    end
end

%Merge GateA and GateB with reward.

for i=1:NumberOfTrials
    if ( GatingARewarded (i) == 1 |  GatingBRewarded (i) == 1)
        GatingRewarded (i) = 1;
    end
end

GatingRewarded 