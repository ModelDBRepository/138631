% in this file, I add noise to wts (wts-perturbation algorithm; See Rowland et al. 2005)

% attentional module
Wts_SAC_PFC_Perturbed(:,1) = Wts_SAC_PFC(:,1) + Noise_SAC_PFC(:,1);

% motor module
Wts_PFC_Motor_Perturbed(:,:) = Wts_PFC_Motor(:,:) + Noise_PFC_Motor(:,:);