% motor module
if (time >= 2)

    for h=1:Num_Motor_Nodes
        Temp=0;
        for m=1:Num_PFC_Nodes
            Temp=Temp+PFC_Act(m)*Wts_PFC_Motor_Perturbed(m,h);
        end
        Motor_Act(h)=Temp;
    end
    Motor_Act = sig_motor(Motor_Act);

    % WTA
    % this file is to compute the unit that the highest value among transiently-active units at each time step.
    % computing the highest index
    % highest function returns the index of the heighest value.
    Ind_Hi_Motor_node=argmax(Motor_Act);
    Hi_Motor_Act = Motor_Act(Ind_Hi_Motor_node);

    % After WTA
    %if (Hi_Motor_Act > ThresholdMotor)  % removed    July 18
    for i=1: Num_Motor_Nodes
        if ( i == Ind_Hi_Motor_node)
            Motor_Act(i) = Hi_Motor_Act;   % shall it be one instead
        else
            Motor_Act(i) = 0;    % shall it more than zero
        end
    end

    Motor_Act_time(:,time) = Motor_Act;

    % how about threshold here---do I need to allow the model not to make any responses at all
    if(Ind_Hi_Motor_node == 1)
        Obs_resp = 'A';
    elseif(Ind_Hi_Motor_node == 2)
        Obs_resp = 'B';
    end

Obs_resp_all(TrlNumTotal,1) = Obs_resp;

end



