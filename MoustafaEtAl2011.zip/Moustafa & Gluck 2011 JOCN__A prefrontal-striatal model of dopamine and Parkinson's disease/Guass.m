function f=Guass(x)
%Gamma=0.2;
%Gamma=0.02;
%Gamma=0.99;
%sigma=0.99;
sigma=2;
f=(1/(sigma*sqrt(2*pi)))*exp((-x.*x)/2*sigma.*sigma);

%large Gamma---> big variations.************

% increase sigma from 1 to 2 led to that Guass (0) gets smaller.

% increase sigma from 0.2 to 0.7 led to that Guass (0) gets smaller.

% how about from 0 to 1.
