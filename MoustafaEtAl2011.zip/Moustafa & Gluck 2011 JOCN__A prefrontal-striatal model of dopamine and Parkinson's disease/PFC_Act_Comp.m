
if (time >= 2)
    % attentional module
    
    PFC_Act = Wts_SAC_PFC_Perturbed.*SAC_Act;
    PFC_Act = sig_atten (PFC_Act);
    
%     if (isequal(experiment_type,'Slots_Rev') & (PhaseNum == 2))
%         PFC_Act = PFC_Act/1000000;
%         PFC_Act = rand(Num_PFC_Nodes,1);
%     end

    % this file is to compute the unit that the highest value among delay-active units and also to compute its index.
    %Remember why I need the index of the highest value.
    % computing the highest index
    % highest function returns the index of the heighest value.
    Ind_Hi_PFC_node=argmax(PFC_Act);
    Hi_PFC_Act = PFC_Act(Ind_Hi_PFC_node);


    %PFC_After_WTA
    %if (Hi_PFC_Act > ThresholdPFC)  % removed    July 18
    for i=1: Num_PFC_Nodes
        if ( i == Ind_Hi_PFC_node)
            PFC_Act(i) = Hi_PFC_Act;   % shall it be one instead
        else
            PFC_Act(i) = 0;    % shall it less than zero
        end
    end

end

PFC_Act_time(:,time) =  PFC_Act;