% Bcause I have changed TDError variable. Here, I will define a function to be able to visualize the TDError.

%TDErrorGen(1:20,10:11)  % this is to see TDError in trials (1:20) at time steps (10,11)
%TDErrorGen(1:20,2)      % at the time of cue.

%TDErrorGen_Dash = zeros (NumberOfTrials, 1); % this is just to add it to TDError coloumn

% TDErrorGen = [TDErrorGen  TDErrorGen_Dash]

% [TDErrorGen(1:20,2) TDErrorGen(1:20,10:11)]


%x=1:20
%plot (TDErrorGen (1,:))


%plot (TDErrorGen (16,:))


%plot (x,TDErrorGen (1,:),'-',x,TDErrorGen (16,:),':')

%plot (x,[TDErrorGen (1,:)  0],'-',x,[TDErrorGen (16,:) 0],':')


%--------------
x=1:12
%y=[TDErrorGen(1,:) 0];
%z=[TDErrorGen(8,:) 0]

%plot (x,y,'-')
%plot(x,z,':')

plot (x,[TDErrorGen(3,:) 0],'-', x,[TDErrorGen(14,:) 0],'-',x,[TDErrorGen(200,:) 0],'-')
 