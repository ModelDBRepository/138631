% in this file I merge all trials in which A or B is gated and also rewarded.
