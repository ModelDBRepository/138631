% Variables that will be zero at end of each trial.
IsAGated=0;    % all these varibales work within a trial.
IsBGated=0;    % this is to re-initialize these variables to zero at the end of each trial 
IsAPresented=0;
IsBPresented=0;

%Reward=[0 0 0 0 0 0 0];  % make sure about that**
Reward=zeros (1,NumTimeSteps);   % March 22


%Prediction=[0 0 0 0 0 0 0];   %make sure.
%Prediction=zeros (1,NumTimeSteps);  % March 22

SAC_Act = zeros(Num_SAC_Nodes,1);
PFC_Act = zeros(Num_PFC_Nodes,1);
Motor_Act = zeros(Num_Motor_Nodes,1);

SAC_Act_time = zeros(Num_SAC_Nodes,NumTimeSteps);
PFC_Act_time = zeros(Num_PFC_Nodes,NumTimeSteps);
Motor_Act_time = zeros(Num_Motor_Nodes,NumTimeSteps);


% % see whether these variables need to be put to zero.
% CorticalNeuronsA=[0 0 0]; %***we may not need this intialization. **Check ChooseACue. Later, it will be [1 0 0]
% CorticalNeuronsB=[0 0 0];  
% CorticalNeuronsX=[0 0 0];
% 
% SNC_NeuronsX = [0 0 0];    % June 15
% SNC_NeuronsA = [0 0 0];    % June 15
% SNC_NeuronsB = [0 0 0];    % June 15
% 
% SNC_WhenAActive=zeros(3,11);  % June 21
% SNC_WhenBActive=zeros(3,11);  % June 21
% SNC_WhenXActive=zeros(3,11);  % June 21


% %DelayActiveUActivation=[0 0 0 0]; % these variables replace GatingUMatrisomesActivation
% %TransientlyActiveUActivation=[0 0 0];
% 
% %WhenAActive=zeros(3,7);  % March 11
% WhenAActive=zeros(3,11);  % March 22
% 
% %WhenBActive=zeros(3,7);  % March 17
% WhenBActive=zeros(3,11);  % March 22
% 
% %WhenXActive=zeros(3,7);
% WhenXActive=zeros(3,11); % March 22
% 
% %WhenTActive=zeros(2,7);
% WhenTActive=zeros(2,11);   % March 22
% 
% %WhenDActive=zeros(2,7);
% WhenDActive=zeros(3,11);  % March 22
% 
% DelayActiveUActivation=[0 0 0]; 
% TransientlyActiveUActivation=[0 0];
% 
% IndexHighestDelayActive = 0;
% HighestValueDelayActive = 0;
% HighestValueTransientlyActive = 0;
% IndexHighestTransientlyActive = 0;
% 
% BreakOccured = 0;
% 
% IsD1Active = 0;
% IsD2Active = 0;
% 
% DUActivationTime2 = [0 0 0];
% IndexHighestDUTime2 = 0;