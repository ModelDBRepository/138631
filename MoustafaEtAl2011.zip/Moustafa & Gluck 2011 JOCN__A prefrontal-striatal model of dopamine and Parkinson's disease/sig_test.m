% Sig_D
function result = sig_test(x,g)
%Gain_D = 30;    % see Initializations2
%Gain = 0.2; % testing the effect of DA reduction in the striatum. persveration
%Gain = 0.6;  % has no big effect
%Gain = 0.4;  % no big effect
%Bias = 0;   % I may add it later.
%Gain = 100000;  %This is to imitate linear units with Threshold = 0

result=1./(1+exp(-g*x));
