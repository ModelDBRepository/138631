% in this file I will see at which trial the model gates a cue but not rewarded at the same time.
% 1 means gated and rewarded; zero otherwise.

GatingANotRewaded = zeros(1, NumberOfTrials);
GatingBNotRewarded = zeros(1, NumberOfTrials);
GatingNotRewarded = zeros(1, NumberOfTrials);

% Match GatingA with Reward

for i=1:NumberOfTrials
    if (IsAGatedGen (i) == 1 & RewardYesNo (i) == 0)
        GatingANotRewaded (i) = 1;
    end
end

% Match GatingB with Reward

for i=1:NumberOfTrials
    if (IsBGatedGen (i) == 1 & RewardYesNo (i) == 0)
        GatingBNotRewarded (i) = 1;
    end
end

%Merge GateA and GateB with reward.

for i=1:NumberOfTrials
    if (GatingANotRewaded (i) == 1 |  GatingBNotRewarded (i) == 1)
        GatingNotRewarded (i) = 1;
    end
end

GatingNotRewarded 