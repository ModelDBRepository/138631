if (isequal(experiment_type,'Slots_Rev') & (PhaseNum == 2)& TrlNum < 300)  % this is first trial in second phase
    
    %Wts_PFC_Motor = Wts_PFC_Motor - 1000*rand(Num_PFC_Nodes,Num_Motor_Nodes);
    %Wts_SAC_PFC = Wts_SAC_PFC - 1000*rand(Num_SAC_Nodes,1);
    
    Wts_PFC_Motor = Wts_PFC_Motor/100;
    Wts_SAC_PFC = Wts_SAC_PFC/100;

    %Wts_PFC_Motor = Wts_PFC_Motor - rand(Num_PFC_Nodes,Num_Motor_Nodes);
    

end

if (isequal(experiment_type,'Crabs_Rev') & (PhaseNum == 2) & TrlNum ==1)  % this is first trial in second phase
   
    Wts_PFC_Motor = rand(Num_PFC_Nodes,Num_Motor_Nodes);
    Wts_SAC_PFC = rand(Num_SAC_Nodes,1); % because it is 1-1.


    %Wts_PFC_Motor = rand(Num_PFC_Nodes,Num_Motor_Nodes);
    

end
%keyboard