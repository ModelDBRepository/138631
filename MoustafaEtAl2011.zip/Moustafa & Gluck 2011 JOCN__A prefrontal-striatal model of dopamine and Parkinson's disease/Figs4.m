% Figs4
% this file is for plots and bars used in the model

% Weight Figures

if(RunNumber == 1)
    % Critic

    plot(Wts_CriticX_1_1)

    hold on
    plot(Wts_CriticA_1_1,':')
    plot(Wts_CriticB_2_1,'-.')
 %   axis([0 1500 0 0.6])                    % Oct. 1
    axis([0 1500 0 0.3])                    % Oct. 17
    xlabel('Trial Number')
    ylabel('Weight Value')
    title('Weight Update in Critic')
    legend('X-S','A-S','B-S')
    hold off
    print -dmfile WtsCritic   
    close
    % T units in trials that inculde X

    %**combine all of them in one figure
    plot(Wts_MotorX_1_1);
    hold on
    plot(Wts_MotorX_1_2,':');
%    axis([0 1500 0.7 1.2]);
    axis([0 1500 0.4 0.7]);
    xlabel('Trial Number');
    ylabel('Weight Value');
    title('Weight Update in X-T pathways');
    legend('X-T1','X-T2');
    hold off
    print -dmfile T_Units_X
    close
    % T-units and A
    plot(Wts_MotorA_1_1);
    hold on
    plot(Wts_MotorA_1_2,':');
    xlabel('Trial Number');
    ylabel('Weight Value');
    title('Weight Update in A-T pathways');
    legend('A-T1','A-T2');
    hold off
    print -dmfile T_Units_A
    % T units in trials that include B
    close

      
    plot(Wts_MotorB_2_2);
    hold on
    plot(Wts_MotorB_2_1,':');
    xlabel('Trial Number');
    ylabel('Weight Value');
    title('Weight Update in B-T pathways');
    legend('B-T2','B-T1');
    hold off
    print -dmfile T_Units_B
    close

    % D units
    plot(Wts_GatingA_1_1);
    hold on
    plot(Wts_GatingB_2_2,':');
    xlabel('Trial Number')
    ylabel('Weight Value')
    title('Weight Update in D-units')
    legend('A-D1','A-D2');
    hold off
    print -dmfile D_Units
    close
    %=========================================================================
    % Effective reinforcement (TD) error
    % I might add here axis function so that I can see X increases by 1.
%    plot([TDErrorGen(6,:) 0])
    plot([TDErrorGen(104,:) 0])

    axis([1 12 0 1])
    hold on
    %plot([TDErrorGen(225,:) 0],':')
%    plot([TDErrorGen(348,:) 0],':')
    plot([TDErrorGen(188,:) 0],':')

    plot([TDErrorGen(1500,:) 0],'--')
    xlabel('Time Step')
    ylabel('Effective Reinforcement Signal')
    title('Time Shifting of Effective Reinforcement Signal')
    legend('Reward','Trigger','Cue')
    hold off
    print -dmfile EffectiveReinforcement
    close
    
    % this is for PR. RunNumber 14
    plot([TDErrorGen(1500,:) 0],'--')
    hold on
    axis([1 12 0 1])
    hold off
    print -dmfile EffectiveReinforcement_PR
    close
    
     % this is for RM. RunNumber 15
    plot([TDErrorGen(1500,:) 0],'--')
    hold on
    axis([1 12 0 1])
    hold off
    print -dmfile EffectiveReinforcement_RM
    close
    
    %3-dim TD figure
    surf(1:11,1:600,TDErrorGen(1:600,1:11))
    
    % MP, GP, and TD
    legend('Correct Motor Responses','Correct Gating','Correct Gating and Rewarded');
    %==========================================================================
    % Motor and Gating performance
    
    % Motor performance
    MeasurePerformanceMotor3
    xlabel('Block Number')
    ylabel('Percentage of Correct Motor Responses')
    title('Motor Performance')
    hold off
    print -dmfile MotorPerformanceFig
    print -dmfile MotorPerformanceFig_PR        % see RunNumber 14
    print -dmfile MotorPerformanceFig_RM        % see RunNumber 15
    close
    % Gating Performance
    MeasurePerformanceGating2   % I may change the name
    xlabel('Block Number')
    ylabel('Percentage of Correct Gating')
    title('Gating Performance')
    hold off
    print -dmfile GatingPerformance
    print -dmfile GatingPerformance_PR
    print -dmfile GatingPerformance_RM
    close
    % Act1 and Act2
%    bar(1,sum(WhatTrialAct1Made),0.1,'b')
%    bar(2,sum(WhatTrialAct2Made),0.1,'w') 
%    legend('Act1','Act2')
%    print -dmfile Act12Fig
   
close
%********************************************************************************************
elseif (RunNumber == 2)
    
    % unconditional reinforcement signal.
    
    % T units in trials that inculde X       *June 22
    plot(Wts_MotorX_1_1);
    hold on
    plot(Wts_MotorX_1_2,':');
    axis([0 1500 0.7 1.2])
    xlabel('Trial Number');
    ylabel('Weight Value');
    title('Weight Update in X-T pathways');
    legend('X-T1','X-T2');
    hold off
    print -dmfile T_Units_X_URS
    close
    
    % effective reinforcement   % may not be very important
    axis([1 12 0 1])
    plot([TDErrorGen(6,:) 0])
    hold on
    plot([TDErrorGen(559,:) 0],':')
    xlabel('Time Step')
    ylabel('Effective Reinforcement Signal')
    title('Time Shifting of Effective Reinforcement Signal and Unconditional Reinforcement')
    legend('Reward','Trigger');
    hold off
    print -dmfile EReinforcement_URS
    close
    
    % Gating Performance
    Run GatingPerformance
    hold on
    MeasurePerformanceGating2
    xlabel('Block Number')
    ylabel('Percentage of Correct Gating')
    title('Gating Performance and Unconditional Reinforcement')
    legend ('Intact Model','Unconditional Reinforcement')
    hold off
    print -dmfile GP_UR

    close
    %=====================================
    
    %Motor Performance when is lesioned
    Run MotorPerformanceFig
    hold on
    MeasurePerformanceMotor3  
    hold on
%    legend ('Intact Gating','Damaged Gating')
   % legend ('std error','D-matrisomes intact','std error','D-matrisomes lesioned')
   % legend ('D-matrisomes intact','D-matrisomes lesioned')
    print -dmfile MotorPerformanceFig
    hold off
    close   
%***********************************************************************************    
    
elseif (RunNumber == 3)    % D-matrisomes are lesioned
   
     % T units in trials that inculde X       *June 22
    plot(Wts_MotorX_1_1);
    hold on
    plot(Wts_MotorX_1_2,':');
    axis([0 1500 0.4 0.7])
    xlabel('Trial Number');
    ylabel('Weight Value');
    title('Weight Update in the X-T Pathway');
    legend('X-T1','X-T2');
    hold off
    print -dmfile T_Units_X_Dlesioned
    close    
     % effective reinforcement
    axis([1 12 0 1])
%    plot([TDErrorGen(6,:) 0])
    plot([TDErrorGen(104,:) 0])
    hold on
    plot([TDErrorGen(559,:) 0],':')
    xlabel('Time Step')
    ylabel('Effective Reinforcement Signal')
    title('Time Shifting of the Effective Reinforcement Signal with Damaged D-matrisomes')
    legend('Reward','Trigger');
    hold off
    print -dmfile EReinforcement_D_Mat_Lesioned
    close
    
    % Motor performance.
    Run MotorPerformanceFig
    hold on
    MeasurePerformanceMotor3  
    hold on
%    legend ('Intact Gating','Damaged Gating')
 %   legend ('intact model','D-matrisomes intact','DLPFC lesioned')
    print -dmfile MotorPerformanceFig
    hold off
        
        
    %***do a figure for TD signal shifting here and also for DLPFC lesioning
    close
%*******************************************************************************************

elseif (RunNumber == 4) % DLPFC is lesioned
           
     % T units in trials that inculde X       *Use SAC not DLPFC units.
    plot(Wts_SAC_MotorX_1_1);
    hold on
    plot(Wts_SAC_MotorX_1_2,':');
    axis([0 1500 0.4 0.7])
    xlabel('Trial Number');
    ylabel('Weight Value');
    title('Weight Update in X-T Pathways');
    legend('X-T1','X-T2');
    hold off
    print -dmfile T_Units_X_DLPFCLesioned
    
    % Effective reinforcement (TD) error
    % I might add here axis function so that I can see X increases by 1.
    plot([TDErrorGen(2,:) 0])
%    plot([TDErrorGen(104,:) 0])
    axis([1 12 0 1])
    hold on
    plot([TDErrorGen(1500,:) 0],':')
    xlabel('Time Step')
    ylabel('Effective Reinforcement Signal')
    title('Time Shifting of the Effective Reinforcement Signal and Lesioning DLPFC')
    legend('Reward','Trigger')
    hold off
    print -dmfile EffectiveReinforcement_DLPFCLesioned
    
    % Motor performance.
    Run MotorPerformanceFig
    hold on
    MeasurePerformanceMotor3  
    hold on
%    legend ('Intact Gating','Damaged Gating')
 %   legend ('intact model','striatal DA reduction','D-matrisomes lesioned','DLPFC lesioned')
    legend ('intact model','Unconditional reinforcement ','D-matrisomes lesioned','DLPFC lesioned')
    print -dmfile MotorPerformanceFig
    hold off
    
    % Act1 and Act2 when gating is lesioned
    %    Run Act12Fig    % see above; this is the file used for Act1 and Act2
    x=[1 2 3 4];
    bar(x, [NAct1 NAct2;NAct1_URS NAct2_URS; NAct1_DMAtLesioned NAct2_DMAtLesioned; sum(WhatTrialAct1Made) sum(WhatTrialAct2Made)])
    Colormap ('gray')
    ylabel('Number of Motor Responses');

  %  set (gca, 'XTickLabels', char('intact model','D-matrisomes lesioned','DLPFC lesioned'))
 %   set (gca, 'XTickLabels', char('Intact model','Striatal DA reduction','D-matrisomes lesioned','DLPFC lesioned'))
    set (gca, 'XTickLabels', char('Intact model','Unconditional reinforcement    ','    D-matrisomes lesioned','    DLPFC lesioned'))
    set (gca, 'XTickLabels', char('       Intact model','Unconditional reinforcement    ','    D-matrisomes lesioned','           DLPFC lesioned'))
    
    set (gca, 'XTickLabels', char('         Intact model','Unconditional reinforcement    ','     D-matrisomes lesioned','           DLPFC lesioned'))

    legend ('R1','R2')
    print -dmfile Act12Fig
%*******************************************************
elseif (RunNumber == 11)         % Damaged Critic
    
    % Motor Performance
    Run MotorPerformanceFig    % make a file like this that will not be used by Run 2,3, and 4.
    hold on
    MeasurePerformanceMotor3
    legend ('Intact Critic','Damaged Critic')
    xlabel('Block Number')
    ylabel('Percentage of Correct Motor Responses')
    title('Motor Performance and Damaging the Critic')
    hold off
    

    % Gating performance
    Run GatingPerformance    % make a file like this that will not be used by Run 2,3, and 4.
    hold on
    MeasurePerformanceGating2
    legend ('Intact Critic','Damaged Critic')
    xlabel('Block Number')
    ylabel('Percentage of Correct Gating')
    title('Gating Performance and Damaging the Critic')
    hold off
    
    % weight update *it is not very significant
     plot(Wts_MotorX_1_1);
    
    axis([0 1500 0.4 0.7])
    
    hold on
    plot(Wts_MotorX_1_2,':');
    % T-units and A
    
    plot(Wts_MotorA_1_1);
    hold on
    plot(Wts_MotorA_1_2,':');   
    
    plot(Wts_MotorB_2_2);
    hold on
    plot(Wts_MotorB_2_1,':');
    % D units
    plot(Wts_GatingA_1_1);
    plot(Wts_GatingB_2_2,':');
   
    xlabel('Trial Number')
    ylabel('Weight Value')
    title('Weight Update in the Matrisomes of the Critic-damaged Model')
    hold off
    print -dmfile Wts_CriticDamaged

%*******************************************************************************
elseif (RunNumber == 12)         %Behavioral extinction


    MeasurePerformanceGating2
    xlabel('Block Number')
    ylabel('Percentage of Correct Gating')
    title('Gating Performance and Extinction')
    hold off
    
    MeasurePerformanceMotor3
    xlabel('Block Number')
    ylabel('Percentage of Correct Motor Responses')
    title('Motor Performance and Extinction')
    hold off

%*******************************************
elseif (RunNumber == 14) % Partial Reinforcement
          
    if (pr == 1)
        % add first TD error for intact model**
        Run EffectiveReinforcement_PR
        plot([TDErrorGen(1495,:) 0],'--') % in this trial, the reward is given.
        legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25')
        title('Effective Reinforcement Signal at a Late Trial and Partial Reinforcement')
        xlabel('Time Step')
        ylabel('Effective Reinforcement Signal')
        hold off
         print -dmfile EffectiveReinforcement_PR2
        close
        
        % Motor Performance
        Run MotorPerformanceFig_PR    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceMotor3
    %    legend ('p = 1','p = 0.5')
%        legend ('p = 1','p = 0.5','p = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Motor Responses')
        title('Motor Performance and Partial Reinforcement')
        hold off
        print -dmfile MP_PR
        close
        
        % Gating performance
        Run GatingPerformance_PR    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceGating2
        legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Gating')
        title('Gating Performance and Partial Reinforcement')
        hold off
        print -dmfile GP_PR
        close
    end
%********************************************************************    
    if (pr == 2)
        
        % add first TD error for intact model
        Run EffectiveReinforcement_PR2
        plot([TDErrorGen(1492,:) 0],'--') % in this trial, the reward is given.
   %     legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25')
        title('Effective Reinforcement Signal at a Late Trial and Partial Reinforcement')
        xlabel('Time Step')
        ylabel('Effective Reinforcement Signal')
        hold off
        print -dmfile EffectiveReinforcement_PR3
        close
        
        % Motor Performance
        Run MP_PR    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceMotor3
   %     legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Motor Responses')
        title('Motor Performance and Partial Reinforcement')
        print -dmfile MP_PR2
        hold off
        close
        
        % Gating performance
        Run GP_PR    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceGating2
        legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Gating')
        title('Gating Performance and Partial Reinforcement')
        print -dmfile GP_PR2
        hold off
    end
    
    if (pr == 3)
        
        % add first TD error for intact model
         Run EffectiveReinforcement_PR3
        plot([TDErrorGen(1493,:) 0],'--') % in this trial, the reward is given.
   %     legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25','p = 0.1')
        title('Effective Reinforcement Signal at a Late Trial and Partial Reinforcement')
        xlabel('Time Step')
        ylabel('Effective Reinforcement Signal')
        hold off
        print -dmfile EffectiveReinforcement_PR4
        close
        
        % Motor Performance
        Run MP_PR2    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceMotor3
   %     legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25','p = 0.1')
        xlabel('Block Number')
        ylabel('Percentage of Correct Motor Responses')
        title('Motor Performance and Partial Reinforcement')
        print -dmfile MP_PR3
        hold off
        close
        
        % Gating performance
        Run GP_PR2   % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceGating2
        legend ('p = 1','p = 0.5')
        legend ('p = 1','p = 0.5','p = 0.25','p = 0.1')
        xlabel('Block Number')
        ylabel('Percentage of Correct Gating')
        title('Gating Performance and Partial Reinforcement')
        print -dmfile GP_PR3
        hold off
    end
 
%************************************************************************************    
elseif (RunNumber == 15) % Reward Magnitude
    
    if (rm == 1)
        % add first TD error for intact model
        Run EffectiveReinforcement_RM
        plot([TDErrorGen(1500,:) 0],'--') % in this trial, the reward is given.
        %    legend ('R = 1','R = 0.5')
        legend ('R = 1','R = 0.5','R = 0.25')
        title('Effective Reinforcement Signal at a Late Training Trial and Reward Magnitude')
        xlabel('Time Step')
        ylabel('Effective Reinforcement Signal')
        hold off
        print -dmfile EffectiveReinforcement_RM2
        close
        
        % Gating performance
        Run  GatingPerformance_RM    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceGating2
        legend ('R = 1','R = 0.5')
        legend ('R = 1','R = 0.5','R = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Gating')
        title('Gating Performance Using Different Reward Magnitude')
        hold off
        print -dmfile GP_RM
        close
        
        % Motor Performance
        Run MotorPerformanceFig_RM    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceMotor3
      %  legend ('R = 1','R = 0.5')
        legend ('R = 1','R = 0.5','R = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Motor Responses')
        title('Motor Performance Using Different Reward Magnitude')
        hold off 
        print -dmfile MP_RM
        close
    elseif (rm == 2)
        % add first TD error for intact model
        Run EffectiveReinforcement_RM2
        plot([TDErrorGen(1500,:) 0],'--') % in this trial, the reward is given.
        %    legend ('R = 1','R = 0.5')
        legend ('R = 1','R = 0.5','R = 0.25')
        title('Effective Reinforcement Signal at a Late Training Trial and Reward Magnitude')
        xlabel('Time Step')
        ylabel('Effective Reinforcement Signal')
        hold off
        print -dmfile EffectiveReinforcement_RM3
        close
        
        % Gating performance
        Run GP_RM    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceGating2
        legend ('R = 1','R = 0.5')
        legend ('R = 1','R = 0.5','R = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Gating')
        title('Gating Performance Using Different Reward Magnitude')
        hold off
        print -dmfile GP_RM2
        close
        
        % Motor Performance
        Run MP_RM    % make a file like this that will not be used by Run 2,3, and 4.
        hold on
        MeasurePerformanceMotor3
      %  legend ('R = 1','R = 0.5')
        legend ('R = 1','R = 0.5','R = 0.25')
        xlabel('Block Number')
        ylabel('Percentage of Correct Motor Responses')
        title('Motor Performance Using Different Reward Magnitude')
        hold off 
        print -dmfile MP_RM2
        close
    end
%************************************************************************************    
%elseif (RunNumber == 15) % Alpha-a manipulation
    

%legend('Intact','Small Actor Learning Rate','Very Small Actor Learning Rate');

%*************************
elseif (RunNumber == 16) % Alpha-a manipulation
    
legend('Larning rate( = 0.006)','Learning rate/18','Learning rate/30');

%**************************************************************************
elseif (RunNumber == 17)   % delayed-reversal task
   
    surf(1:11,501:1000,TDErrorGen(501:1000,1:11))   % 500 was the end of intact model learning
    
    % weight update in the model
    plot(Wts_MotorX_1_1);
    axis([0 1600 0.1 0.7])
    hold on
    plot(Wts_MotorX_1_2,':');
    
    % T-units and A
    plot(Wts_MotorA_1_1);
    axis([0 1600 0.1 0.6])
    plot(Wts_MotorA_1_2,':'); 
    
    % T-units and B
    
    plot(Wts_MotorB_2_2);
    plot(Wts_MotorB_2_1,':');
    % D units
    plot(Wts_GatingA_1_1);
    plot(Wts_GatingB_2_2,':');
    
    xlabel('Trial Number')
    ylabel('Weight Value')
    title('Weight Update in the Matrisomes in a Delayed-reversal Task')
    hold off
    print -dmfile Wts_Reversal2    
    
%**********************************************************************************    
end