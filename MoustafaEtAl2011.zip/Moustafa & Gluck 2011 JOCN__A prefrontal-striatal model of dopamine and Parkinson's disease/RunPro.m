close
clear all; clc

%rand('state',0);
%randn('state',0);

NumRuns = 1;

for RunNum = 1: NumRuns
    Initializations2
    for PhaseNum = 1:NumPhases
        for TrlNum=1:NumTrls(PhaseNum)
            for time = 1: NumTimeSteps % time represents subtrl
                
                %Reversal_Perf
                Reversal_Perf_gradual
                SAC_Act_Comp

                RandomnessG4
                AddingNoiseToWts

                PFC_Act_Comp

                Motor_Act_Comp

                RewardingModel2

                CriticModified14  %**do it after actor

                %keyboard

                Wts_Update_Atten_Motor

            end

            TrlNumTotal = TrlNumTotal +1;  % this  runs across all phases

            %PutZero
        end
    end
end
TrlNumTotal = TrlNumTotal - 1; % this is because it adds one to total number of trials

%Figs4
[TDError_all double(Obs_resp_all)]

