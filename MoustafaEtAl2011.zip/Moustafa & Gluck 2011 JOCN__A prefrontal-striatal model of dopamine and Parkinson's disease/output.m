time
TrlNum
SAC_Act
PFC_Act
Motor_Act
TDError
Prediction
Wts_PFC_Motor
Wts_SAC_PFC
Wts_SAC_Critic
Obs_resp
Correct_resp
[TDError_all double(Obs_resp_all)]