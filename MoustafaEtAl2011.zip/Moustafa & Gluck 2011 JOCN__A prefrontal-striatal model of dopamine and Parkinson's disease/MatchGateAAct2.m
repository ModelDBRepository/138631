% this is file is to see whether the model Gates A and make Act2 and 
GateAAct2=zeros (1, NumberOfTrials);

for i=1:NumberOfTrials
    if (IsAGatedGen (i) == 1 & WhatTrialAct2Made(i) == 1)
        GateAAct2 (i) = 1;
    end
end

GateAAct2