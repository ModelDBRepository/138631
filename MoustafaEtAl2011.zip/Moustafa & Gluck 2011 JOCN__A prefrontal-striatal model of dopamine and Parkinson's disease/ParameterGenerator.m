% In this file I generate the parameters I need to use in the program.
% First, I will try to generate ThreshdT
% It has to meet the four equations I have in my notes.

% A good ThresholdT would be in [2,3]
% here, I assign some values to noise, but later I will try to generate noise manipulation formulas.

% run this file after I run RunPro
% I still need to put Equation 4.
% I might need to write similar equations for the cue B.

for i=1:100000
    ThresholdT = 1+(0.001*i);
    
    Equation1 = 0; % this variable tells me whether equation 1 met or not (1 or 0).
    Equation2 = 0; % this variable tells me whether equation 2 met or not (1 or 0).
    Equation3 = 0; % this variable tells me whether equation 3 met or not (1 or 0).
    Temp=0;
    for j=1:3
        Temp =Temp+CorticalNeuronsA(j)*(CorticoStriatalWtsActorMotorA(j,1)+CortcoStriatalNoiseActorMotorA(j,1));
    end
    if (Temp < PotentialThresholdT)
        'Equation 1 in my notes is met'
        Equation1 = 1;
    end
    %******************************
    % Make sure eqn 2 is met before equ 3.
    % I think that equ 2 is not met iff WtsMotorX decreases.
    Temp = 0;
    for j=1:3
        Temp = Temp + CorticalNeuronsX(j)*(CorticoStriatalWtsActorMotorX(j,1)+CortcoStriatalNoiseActorMotorX(j,1));
    end
    if (Temp > PotentialThresholdT)
        'Equation 2 in my notes is met'
        Equation2 = 1;
    end
    %******************************
    Temp1 = 0;
    Temp2 = 0;
    for j=1:3
        Temp1 = Temp1 + CorticalNeuronsA(j)*(CorticoStriatalWtsActorMotorA(j,1)+CortcoStriatalNoiseActorMotorA(j,1));
        Temp2 = Temp2 + CorticalNeuronsX(j)*(CorticoStriatalWtsActorMotorX(j,1)+CortcoStriatalNoiseActorMotorX(j,1));
    end
    if (Temp1 + Temp2 > PotentialThresholdT)
        'Equation 3 in my notes is met'
        Equation3 = 1;
    end
    
    
    if (Equation1 == 1 & Equation2 == 1 & Equation3 == 1)
    %if (Equation1 == 1)
        PotentialThresholdT
        'Eurka'
        break;
    end
end
        
        