%RewardingModel2
if(time == 1)  
    Reward(time)=0;
elseif(time >= 3)    % it was 2...check with my PhD model
    if (Obs_resp == Correct_resp) % this means correct response is made.
        Reward(time)=1;       
    else
        Reward(time)=0;        
    end
    
    Reward_all(TrlNumTotal,1) = Reward(NumTimeSteps);   % this also measure correct response. NumTimeSteps is last time step
end



