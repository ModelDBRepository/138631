% sig functions
x = -1:0.1:1
hold on;
plot(x,sig_test(x,2),'LineWidth',3);
plot(x,sig_test(x,5),'LineWidth',3);
%plot(x,sig_test(x,0.1),'LineWidth',3);

xlabel('Input','fontsize',14,'fontweight','b')
ylabel('Activation Level','fontsize',14,'fontweight','b');
title(' Sigmoidal function','fontsize',14,'fontweight','b');
legend('Small Gain','Large Gain');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

% instrumental conditioning (A+)

%performance
%MeasurePerformanceMotor   % this is will run this file
x=1:4; % this is the number of blocks
%plot(x,mean(RewardBlockTrial),'LineWidth',3);  
%plot(x,HC_perf,'LineWidth',3);  
errorbar(x,HC_perf,[0.02 0.04 0.02 0],'g','LineWidth',3);  
hold on
errorbar(x,PDoff_perf,[0.02 0.01 0.01 0.01],'r:','LineWidth',3);  
errorbar(x,PDon_perf,[0.01 0.02 0.02 0.01],'r--','LineWidth',5);  
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title('  Instrumental conditioning performance','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

% attentional wts....HC
plot(Wts_SAC_PFC_HC_all2(3,1:200),'LineWidth',3);  % relevant
hold on;
plot(Wts_SAC_PFC_HC_all2(1,1:200),'--','LineWidth',3);
plot(Wts_SAC_PFC_HC_all2(2,1:200),'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Acquisition Performance','fontsize',14,'fontweight','b');
legend('Dimension 3','Dimension 1','Dimension 2');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 

% attentional wts....PD on
plot(Wts_SAC_PFC_PDon_all2(3,1:200),'LineWidth',3);  % relevant
hold on;
plot(Wts_SAC_PFC_PDon_all2(1,1:200),'--','LineWidth',3);
plot(Wts_SAC_PFC_PDon_all2(2,1:200),'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Acquisition Performance','fontsize',14,'fontweight','b');
legend('Dimension 3','Dimension 1','Dimension 2');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 

% attentional wts....PD off
plot(Wts_SAC_PFC_PDoff_all2(3,1:200),'LineWidth',3);  % relevant
hold on;
plot(Wts_SAC_PFC_PDoff_all2(1,1:200),'--','LineWidth',3);
plot(Wts_SAC_PFC_PDoff_all2(2,1:200),'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Acquisition Performance','fontsize',14,'fontweight','b');
legend('Dimension 3','Dimension 1','Dimension 2');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 

%===============================TD error================================%======================
% TD error---early trial
%stem(1:4, [TDError_all(1,:) 0],'k','fill');  % do it only CS and US
stem(1:4,TD_Early,'k','fill'); 
hold on
title('Early Training Trial','fontsize',14,'fontweight','b');
ylabel('TD Error','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1]);  % this is to make the background color white 
%set (gca, 'XTickLabels', char('                ','CS   ','    US ','            '));
set (gca, 'XTick',[]);    % this is to remove Xticks

% TD error---late trial
%stem(1:4, [TDError_all(1,:) 0],'k','fill');  % do it only CS and US
stem(1:4,TD_Late,'k','fill'); 
hold on
title('Late Training Trial','fontsize',14,'fontweight','b');
ylabel('TD Error','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1]);  % this is to make the background color white 
%set (gca, 'XTickLabels', char('                ','CS   ','    US ','            '));
set (gca, 'XTick',[]);    % this is to remove Xticks

% Slots
%===============================performance======================================================
% performance--acq
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
%plot(x,mean(RewardBlockTrial),'LineWidth',3);  
%plot(HC_acq,'LineWidth',3);    % acq is acquistion phase in Slots
errorbar(HC_acq,[0.02 0.04 0.01 0.01],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
%plot(PDoff_acq,'LineWidth',3);  
errorbar(PDoff_acq,[0.01 0.02 0.01 0.01],'r:','LineWidth',3); 
%plot(PDon_acq,'LineWidth',3);  
errorbar(PDon_acq,[0.02 0.02 0.01 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Acquistion Performance','fontsize',14,'fontweight','b');
legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

% performance--rev
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
%plot(x,mean(RewardBlockTrial),'LineWidth',3);  
errorbar(HC_rev,[0.02 0.03 0.02 0.01],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
errorbar(PDoff_rev,[0.03 0.04 0.01 0.01],'r:','LineWidth',3);  
errorbar(PDon_rev,[0.02 0.04 0.01 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

% PFC lesioned vs. intact

% performance--acq
subplot(1,2,1)
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
%plot(x,mean(RewardBlockTrial),'LineWidth',3);  
%plot(HC_acq,'LineWidth',3);    % acq is acquistion phase in Slots
errorbar(HC_acq,[0.02 0.04 0.01 0.01],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
errorbar(HC_acq_PFClesioned,[0.02 0.02 0.01 0.01],'g:','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Acquistion Performance','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

% performance--rev
subplot(1,2,2)
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
%plot(x,mean(RewardBlockTrial),'LineWidth',3);  
errorbar(HC_rev,[0.02 0.03 0.02 0.01],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
errorbar(HC_rev_PFClesioned,[0.02 0.04 0.01 0.01],'g:','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

%===============================Wts======================================================
%===============HC=====================
subplot(1,2,1)
% weight--attention--acq
plot(Wts_atten_Acq_HC_relevantDim,'LineWidth',3);   % relevant = attended-to cue.
hold on;
plot(Wts_atten_Acq_HC_irrelevantDim2,'--','LineWidth',3);
plot(Wts_atten_Acq_HC_irrelevantDim1,'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Acquisition Performance','fontsize',14,'fontweight','b');
legend('Dimension 2','Dimension 1','Dimension 3');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

% weight--attention--rev
subplot(1,2,2)
plot(Wts_atten_Rev_HC_relevantDim,'LineWidth',3);   % relevant = attended-to cue.
hold on;
plot(Wts_atten_Rev_HC_irrelevantDim2,'--','LineWidth',3);
plot(Wts_atten_Rev_HC_irrelevantDim1,'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b');
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
legend('Dimension 2','Dimension 1','Dimension 3');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 


%===============PD off ===================== same as HC with some noise less
subplot(1,2,1)
plot(Wts_atten_Acq_PDoff_relevantDim,'LineWidth',3);   % relevant = attended-to cue.
hold on;
plot(Wts_atten_Acq_PDoff_irrelevantDim2,'LineWidth',3);
plot(Wts_atten_Acq_PDoff_irrelevantDim1,'LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Acquisition Performance','fontsize',14,'fontweight','b');
legend('Dimension 2','Dimension 1','Dimension 3');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

subplot(1,2,2)
% weight--attention--rev
plot(Wts_atten_Rev_PDoff_relevantDim,'LineWidth',3);   % relevant = attended-to cue.
hold on;
plot(Wts_atten_Rev_PDoff_irrelevantDim2,'LineWidth',3);
plot(Wts_atten_Rev_PDoff_irrelevantDim1,'LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b');
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
legend('Dimension 2','Dimension 1','Dimension 3');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 

%===============PD on =====================
% weight--attention--acq
subplot(1,2,1)
plot(Wts_atten_Acq_PDon_relevantDim,'LineWidth',3);   % relevant = attended-to cue.
hold on;
plot(Wts_atten_Acq_PDon_irrelevantDim1,'--','LineWidth',3);
plot(Wts_atten_Acq_PDon_irrelevantDim2,'--','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Acquisition Performance','fontsize',14,'fontweight','b');
legend('Dimension 2','Dimension 1','Dimension 3');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

subplot(1,2,2)
% weight--attention--rev
plot(Wts_atten_Rev_PDon_irrelevantDim1,'LineWidth',3);   % his is dim 2 that became irrlevant in reversal.
hold on;
plot(Wts_atten_Rev_PDon_relevantDim,'--','LineWidth',3);   % relevant = attended-to cue.
plot(Wts_atten_Rev_PDon_irrelevantDim2,'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b');
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
legend('Dimension 2','Dimension 1','Dimension 3');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 


% Number of Subjects doing reversal same cue or other cue
%out of 100 hundreds runs..order is controls..PD on..PD off.
% I predict that PD off will reverse same way as controls.
bar([98 0;29 69],'grouped');
hold on;
ylabel('Percentage of Simulation Runs','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 
title(' Reversal Performance','fontsize',14,'fontweight','b');
legend('Same Cue in Reversal','New Cue in Reversal');


% num of runs...PD off only
bar([99 1; 0 0],'grouped');
hold on;
ylabel('Percentage of Simulation Runs','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 
title(' Reversal Performance','fontsize',14,'fontweight','b');
legend('Same Cue in Reversal','New Cue in Reversal');


%Crabs
% do a figure for performance---similar to that of Slots****
% perseverative errors
% order is controls..PD off..PD on--as in Robb's paper

bar([0.281 0 0; 0 0.491 0; 0 0 0.3],2.0);
hold on;
ylabel('Percentage of Perseverative Errors','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 
title(' Reversal Performance','fontsize',14,'fontweight','b');


% Weather prediction

%performance
MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
%plot(x,mean(RewardBlockTrial),'LineWidth',3);  
%plot(x,HC_perf,'g','LineWidth',3);  
errorbar(HC_perf,[0.05 0.02 0.02 0.01],'g','LineWidth',3);  
hold on
%plot(x,PDoff_perf,'r:','LineWidth',3);  
errorbar(x,PDoff_perf,[0.05 0.02 0.02 0.01],'r:','LineWidth',3);  
%plot(x,PDon_perf,'r--','LineWidth',3);  
errorbar(x,PDon_perf,[0.05 0.02 0.02 0.01],'r--','LineWidth',5);  
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Weather Prediction performance','fontsize',14,'fontweight','b');
set(gcf,'Color',[1,1,1])  % this is to make the background color white   


% attentional wts....HC
plot(Wts_SAC_PFC_HC_all2(3,1:200),'LineWidth',3);  % relevant
hold on;
plot(Wts_SAC_PFC_HC_all2(1,1:200),'--','LineWidth',3);
plot(Wts_SAC_PFC_HC_all2(2,1:200),'.','LineWidth',3);
plot(Wts_SAC_PFC_HC_all2(4,1:200),'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Weather prediction','fontsize',14,'fontweight','b');
legend('Dimension 3','Dimension 1','Dimension 2', 'Dimension 4');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 

% attentional wts....HC
plot(Wts_SAC_PFC_HC_all3(3,1:200),'LineWidth',3);  % relevant
hold on;
plot(Wts_SAC_PFC_HC_all3(1,1:200),'--','LineWidth',3);
plot(Wts_SAC_PFC_HC_all3(2,1:200),'.','LineWidth',3);
plot(Wts_SAC_PFC_HC_all3(4,1:200),'.','LineWidth',3);
xlabel('Trial Number','fontsize',14,'fontweight','b')
ylabel('weight value','fontsize',14,'fontweight','b');
title(' Weather prediction','fontsize',14,'fontweight','b');
legend('Cue 1','Cue 2','Cue 3', 'Cue 4');
set(gcf,'Color',[1,1,1])  % this is to make the background color white 

% Slots1cue

subplot(1,2,1)
% performance--acq
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
errorbar(HC_acq_1cue,[0.01 0.03 0.02 0.006],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
%plot(PDoff_acq,'LineWidth',3);  
errorbar(PDoff_acq_1cue,[0.02 0.01 0.01 0.01],'r:','LineWidth',3); 
%plot(PDon_acq,'LineWidth',3);  
errorbar(PDon_acq_1cue,[0.01 0.024 0.02 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Acquistion Performance','fontsize',14,'fontweight','b');
%legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white  

subplot(1,2,2)
% performance--rev
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
errorbar(HC_rev_1cue,[0.01 0.02 0.01 0.02],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
errorbar(PDoff_rev_1cue,[0.01 0.02 0.01 0.02],'r:','LineWidth',3);  
errorbar(PDon_rev_1cue,[0.01 0.02 0.03 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
%legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

% Slots_Shifts

subplot(1,2,1)
% performance--acq
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
errorbar(HC_acq,[0.01 0.03 0.02 0.006],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
%plot(PDoff_acq,'LineWidth',3);  
errorbar(PDoff_acq,[0.02 0.01 0.01 0.01],'r:','LineWidth',3); 
%plot(PDon_acq,'LineWidth',3);  
errorbar(PDon_acq,[0.01 0.024 0.02 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Acquistion Performance','fontsize',14,'fontweight','b');
%legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white  

subplot(1,2,2)
% performance--rev
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
errorbar(HC_rev,[0.01 0.02 0.01 0.02],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
errorbar(PDoff_rev,[0.01 0.02 0.01 0.02],'r:','LineWidth',3);  
errorbar(PDon_rev,[0.01 0.02 0.03 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
%legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white   



%==========================================================================
%graphing slots1cue and shifting together

% Slots1cue

subplot(1,3,1)
% performance--acq
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
errorbar(HC_acq_1cue,[0.01 0.03 0.02 0.006],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
%plot(PDoff_acq,'LineWidth',3);  
errorbar(PDoff_acq_1cue,[0.02 0.01 0.01 0.01],'r:','LineWidth',3); 
%plot(PDon_acq,'LineWidth',3);  
errorbar(PDon_acq_1cue,[0.01 0.024 0.02 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Acquistion Performance','fontsize',14,'fontweight','b');
%legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white  

subplot(1,3,2)
% performance--rev
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
errorbar(HC_rev_1cue,[0.01 0.02 0.01 0.02],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
errorbar(PDoff_rev_1cue,[0.01 0.02 0.01 0.02],'r:','LineWidth',3);  
errorbar(PDon_rev_1cue,[0.01 0.02 0.03 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
%legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white   

subplot(1,3,3)
% performance--rev
%MeasurePerformanceMotor   % this is will run this file
x=1:NumTrls(1)/LengthOfBlock; % this is the number of blocks
errorbar(HC_rev,[0.01 0.02 0.01 0.02],'g','LineWidth',3);    % acq is acquistion phase in Slots
hold on
errorbar(PDoff_rev,[0.01 0.02 0.01 0.02],'r:','LineWidth',3);  
errorbar(PDon_rev,[0.01 0.02 0.03 0.01],'r--','LineWidth',5);  
hold on
xlabel('Block Number','fontsize',14,'fontweight','b')
ylabel('Percentage Correct','fontsize',14,'fontweight','b');
title(' Reversal Performance','fontsize',14,'fontweight','b');
%legend('HC','PD Off','PD On')
set(gcf,'Color',[1,1,1])  % this is to make the background color white   





