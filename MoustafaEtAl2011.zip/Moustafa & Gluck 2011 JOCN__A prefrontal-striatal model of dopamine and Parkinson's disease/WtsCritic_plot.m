plot(Wts_CriticA_1_1)
hold on
plot(Wts_CriticX_1_1)
plot(Wts_CriticX_1_1)