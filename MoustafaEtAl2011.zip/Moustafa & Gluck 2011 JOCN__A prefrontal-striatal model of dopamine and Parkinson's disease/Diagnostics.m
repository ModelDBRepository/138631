% Diagnostics   
% my main concern here is A-T1 weight
% Equations 1-4 in my notes are sufficient but not necessary for model's correctness.
% Equations 1-3 (after learning) and equation 4 (before learning)
% Eqn 2 true --> Equ 3 is true (but not vice versa)
% the model can correctly perform the task even if equation 2 and 3 are not met.
% Equation 4 is the least important.
                                    % After Learning
Temp=0;
for j=1:3
    Temp =Temp+CorticalNeuronsA(j)*(CorticoStriatalWtsActorMotorA(j,1)+CortcoStriatalNoiseActorMotorA(j,1));
end
if (Temp < ThresholdT)
    'Equation 1 in my notes is met'
end
%******************************
% Make sure eqn 2 is met before equ 3.
% I think that equ 2 is not met iff WtsMotorX decreases.
Temp = 0;
for j=1:3
    Temp = Temp + CorticalNeuronsX(j)*(CorticoStriatalWtsActorMotorX(j,1)+CortcoStriatalNoiseActorMotorX(j,1));
end
if (Temp > ThresholdT)
    'Equation 2 in my notes is met'
end
%******************************
Temp1 = 0;
Temp2 = 0;
for j=1:3
    Temp1 = Temp1 + CorticalNeuronsA(j)*(CorticoStriatalWtsActorMotorA(j,1)+CortcoStriatalNoiseActorMotorA(j,1));
    Temp2 = Temp2 + CorticalNeuronsX(j)*(CorticoStriatalWtsActorMotorX(j,1)+CortcoStriatalNoiseActorMotorX(j,1));
end
if (Temp1 + Temp2 > ThresholdT)
    'Equation 3 in my notes is met'
end
%**************************************
% Equation 4
Temp3=0;
for j=1:3
    %Temp3 =Temp3+CorticalNeuronsA(j)*(CorticoStriatalWtsActorMotorA(j,1)+CortcoStriatalNoiseActorMotorA(j,1));
    Temp3 =Temp3+ CorticalNeuronsA(j)*( 0.9 +( (randn*0.4)+0.6) );
    % 0.9 is the initial weight
    %( randn*0.4)+0.6) is the initial weight.

end
if (Temp3 > ThresholdT)
    'Equation 4 in my notes is met'
end



