% in this file I will see at which trial the model gates a cue and get rewarded at the same time.
%1 here means not gated but rewarded; zero otherwise.
%**************not working
NotGatingARewaded = zeros(1, NumberOfTrials);
NotGatingBRewarded = zeros(1, NumberOfTrials);
NotGatingRewarded = zeros(1, NumberOfTrials);

% Match GatingA with Reward

for i=1:NumberOfTrials
    if (IsAGatedGen (i) == 0 & RewardYesNo (i) == 1)
        NotGatingARewaded (i) = 1;
    end
end

% Match GatingB with Reward

for i=1:NumberOfTrials
    if (IsBGatedGen (i) == 0 & RewardYesNo (i) == 1)
        NotGatingBRewarded (i) = 1;
    end
end

%Merge GateA and GateB with reward.

for i=1:NumberOfTrials
    if (NotGatingARewaded (i) == 1 |  NotGatingBRewarded (i) == 1)
        NotGatingRewarded (i) = 1;
    end
end

NotGatingRewarded 