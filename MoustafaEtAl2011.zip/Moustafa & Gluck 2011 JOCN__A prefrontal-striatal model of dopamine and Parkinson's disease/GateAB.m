% this file is to merge GateA and GateB. (not necessarily rewardded).
IsAOrBGated=zeros (1, NumberOfTrials);
for i=1:NumberOfTrials
    if (IsAGatedGen (i) == 1 | IsBGatedGen (i) == 1)
        IsAOrBGated (i)=1;
    end
end
IsAOrBGated