%   X  Y  A B C.... C is another cue replacing US
% order is same as in Table 1, shohamy's paper
%          Candle    Fish     Boat     ctx     ctx
%          Lightbulb Butterfly Plane
Input_1 = [1 1 1];   % Candle Fish Boat
Input_2 = [1 1 0];   % 
Input_3 = [1 0 1];   % 
Input_4 = [1 0 0];   % 
Input_5 = [0 1 1];   % 
Input_6 = [0 1 0];   % 
Input_7 = [0 0 1];   % 
Input_8 = [0 0 0];   % 

% later I will randomize order presentation
NumCases = 8;
if(isequal(experiment_type,'Slots') | (isequal(experiment_type,'Slots_Rev') & (PhaseNum == 1)))
    if (mod(TrlNum,NumCases) == 1)  % Input_1....10 is because of Num of trls is 10
        SAC_Act = Input_1; 
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 2) 
        SAC_Act = Input_2;  
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 3) 
        SAC_Act = Input_3; 
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 4)
        SAC_Act = Input_4;
        Correct_resp = ' B';
    elseif(mod(TrlNum,NumCases) == 5) 
        SAC_Act = Input_5;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 6) 
        SAC_Act = Input_6;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 7) 
        SAC_Act = Input_7;
        Correct_resp = 'B';
%     elseif(mod(TrlNum,NumCases) == 8) 
%         SAC_Act = Input_8; 
%         Correct_resp = 'B';
%     elseif(mod(TrlNum,NumCases) == 9) 
%         SAC_Act = Input_1; 
%         Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 0) 
        SAC_Act = Input_8; 
        Correct_resp = 'B';
    end   
elseif (isequal(experiment_type,'Slots_Rev') & (PhaseNum == 2))
    if (mod(TrlNum,NumCases) == 1)  % Input_1....10 is because of Num of trls is 10
        SAC_Act = Input_1; 
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 2) 
        SAC_Act = Input_2;  
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 3) 
        SAC_Act = Input_3; 
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 4)
        SAC_Act = Input_4;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 5) 
        SAC_Act = Input_5;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 6) 
        SAC_Act = Input_6;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 7) 
        SAC_Act = Input_7;
        Correct_resp = 'B';
%     elseif(mod(TrlNum,NumCases) == 8) 
%         SAC_Act = Input_8; 
%         Correct_resp = 'A';
%     elseif(mod(TrlNum,NumCases) == 9) 
%         SAC_Act = Input_1; 
%         Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 0) 
        SAC_Act = Input_8; 
        Correct_resp = 'B';
    end 
end


