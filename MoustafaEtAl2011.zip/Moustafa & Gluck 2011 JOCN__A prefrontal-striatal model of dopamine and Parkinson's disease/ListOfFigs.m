% ListOfFigs
WtsCritic
T_Units_X
T_Units_A
T_Units_B
D_Units
EffectiveReinforcement
MotorPerformanceFig
GatingPerformance
EReinforcement_D_Mat_Lesioned
Act12Fig