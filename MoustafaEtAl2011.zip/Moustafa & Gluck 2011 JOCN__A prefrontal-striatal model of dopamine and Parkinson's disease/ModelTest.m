TDErrorGen
MeasurePerformanceMotor2

CorticoStriatalWtsActorGatingA
CorticoStriatalWtsActorGatingB
CorticoStriatalWtsActorGatingX

CorticoStriatalWtsActorMotorA
CorticoStriatalWtsActorMotorB
CorticoStriatalWtsActorMotorX

AfterTrainingA2
AfterTrainingB2

sum(IsAGatedGen)
sum(IsBGatedGen)
sum(IsXGatedGen)

sum(WhatTrialAct1Made)
sum(WhatTrialAct2Made)

sum(CountMotorAct1Time2)
sum(CountMotorAct2Time2)
sum(CountMotorAct2Delay)
sum(CountMotorAct1Delay)

plot(Wts_Noise_MotorX_1_1)
plot(Wts_Noise_MotorA_1_1)


CueDelayUnitReward

%*************************************************
