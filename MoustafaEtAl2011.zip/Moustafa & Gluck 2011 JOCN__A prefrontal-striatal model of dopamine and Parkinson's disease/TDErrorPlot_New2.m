plot (x,[TDErrorGen(7,:) 0],'-')
hold on
axis([1 12 0 1])
plot (x,[TDErrorGen(41,:) 0],'r')
plot (x,[TDErrorGen(197,:) 0],'g')
xlabel('Time Step')
ylabel('TD Error')




