

% atten module
if (time >= 2)
    for i=1:Num_SAC_Nodes  % 3
        %Wts_SAC_PFC(i)= Wts_SAC_PFC(i)+LR_atten*TDError(time)*SAC_Act_time(i,time-1)*PFC_Act_time(i,time-1);
        Wts_SAC_PFC(i)= Wts_SAC_PFC(i)+LR_atten*TDError(time)*SAC_Act(i)*PFC_Act(i);
    end
end

% motor module
if (time >= 2)  % how about time 1
    for i=1:Num_Motor_Nodes
        for j=1:Num_PFC_Nodes
            %Wts_PFC_Motor(j,i)= Wts_PFC_Motor(j,i)+LR_motor*TDError(time)*PFC_Act_time(j,time-1)*Motor_Act_time(i,time-1);  % shall I add time factor to PFC_act and so forth
            Wts_PFC_Motor(j,i)= Wts_PFC_Motor(j,i)+LR_motor*TDError(time)*PFC_Act(j)*Motor_Act(i);  % shall I add time factor to PFC_act and so forth
        end
    end
end
% Negative weights are assigned zero (see UGateX)


Wts_SAC_PFC_all(:,TrlNumTotal) = Wts_SAC_PFC;

Wts_PFC_Motor_all(:,:,TrlNumTotal) = Wts_PFC_Motor;