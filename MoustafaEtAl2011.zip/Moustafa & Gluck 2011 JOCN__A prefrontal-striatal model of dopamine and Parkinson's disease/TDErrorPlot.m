TDErrorGen3=zeros (1,13, NumberOfTrials); 
for i=1:11
    for j=1:NumberOfTrials
        TDErrorGen3(1,i,j)=TDErrorGen(1,i,j);
    end
end