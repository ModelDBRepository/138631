% In this file, I will generate all parameteres (ThresholdT, NoiseDecrease Parameters, and may be ThresholdD)
% Later, I may add ThresholdD, Sigma, Mean
% put potential range for all of these variables
for i=1:10000  % i is for ThresholdT
    ThresholdT = 1+(0.001*i);
    for ParameterD = 100:100000
        for j=1:1000
            ParameterD2 = (0.001*j);
            
            
            RunPro
            
            
            Equation1 = 0; % this variable tells me whether equation 1 met or not (1 or 0).
            Equation2 = 0; % this variable tells me whether equation 2 met or not (1 or 0).
            Equation3 = 0; % this variable tells me whether equation 3 met or not (1 or 0).
            Temp=0;
            for j=1:3
                Temp =Temp+CorticalNeuronsA(j)*(CorticoStriatalWtsActorMotorA(j,1)+CortcoStriatalNoiseActorMotorA(j,1));
            end
            if (Temp < ThresholdT)
                'Equation 1 in my notes is met'
                Equation1 = 1;
            end
            %******************************
            % Make sure eqn 2 is met before equ 3.
            % I think that equ 2 is not met iff WtsMotorX decreases.
            Temp = 0;
            for j=1:3
                Temp = Temp + CorticalNeuronsX(j)*(CorticoStriatalWtsActorMotorX(j,1)+CortcoStriatalNoiseActorMotorX(j,1));
            end
            if (Temp > ThresholdT)
                'Equation 2 in my notes is met'
                Equation2 = 1;
            end
            %******************************
            Temp1 = 0;
            Temp2 = 0;
            for j=1:3
                Temp1 = Temp1 + CorticalNeuronsA(j)*(CorticoStriatalWtsActorMotorA(j,1)+CortcoStriatalNoiseActorMotorA(j,1));
                Temp2 = Temp2 + CorticalNeuronsX(j)*(CorticoStriatalWtsActorMotorX(j,1)+CortcoStriatalNoiseActorMotorX(j,1));
            end
            if (Temp1 + Temp2 > ThresholdT)
                'Equation 3 in my notes is met'
                Equation3 = 1;
            end
            if (Equation1 == 1 & Equation2 == 1 & Equation3 == 1)
                %if (Equation1 == 1)
                ThresholdT
                ParameterD
                ParameterD2
                'Eurka'
                break;
            end
            
        end
    end
end
    
