% MeasurePerformanceMotor
%this is a file to measure motor performance of the model by learning.
% I will do each phase by itself
LengthOfBlock = 350;
CountMotorPerformance=zeros (1, NumTrls(1)/LengthOfBlock);  % count is used to count how many correct motor response are made in a block of trials
% The number of entries in Count equals to NumberOfTrials/LengthOfBlock
% I will define an 2-D array, one dimension for the block and the other for trials within each block.
% Columns are for blocks while rows are for trials.
RewardBlockTrial = zeros (LengthOfBlock,NumTrls(1)/LengthOfBlock); % April 1

for i=1:NumTrls(1)         
    m=floor (i/LengthOfBlock); % floor and division represents div (used in number theory).
    % m shift from a block to another.    
    if (i/LengthOfBlock ~= floor (i/LengthOfBlock))% this is when the trial is 10, 20, etc, are presented. (this is when the trial number is different from 
        m=m+1;
    end    
    if(Reward_all(i) == 1)
        CountMotorPerformance(1,m)=CountMotorPerformance(1,m)+1;
    end
    
    t=mod (i,LengthOfBlock);  % April 1.
    if(Reward_all (i) == 1)  % April 1
         if (t ~= 0)
             RewardBlockTrial(t,m)=1;
         else   
             RewardBlockTrial(LengthOfBlock,m)=1;
         end
     end
    
end
% this is to draw the error bars
plot(mean(RewardBlockTrial),'LineWidth',3);  
