% March 31, 2005.
% In this file, I measure the development of motor performance as related to the time shifting of the TD Error

% first, I will find the trial that has the highest TD Error at the time of X presentation.
HighestTDErrorX = 0; 
TrialHighestTDErrorX = 0; 
for i=1:NumberOfTrials
    %if (TDErrorGen(1,10,i) > HighestTDErrorX)
    if (TDErrorGen(i,10) > HighestTDErrorX)    
        HighestTDErrorX = TDErrorGen(i,10);
        TrialHighestTDErrorX = i;
    end
end 
HighestTDErrorX 
TrialHighestTDErrorX
