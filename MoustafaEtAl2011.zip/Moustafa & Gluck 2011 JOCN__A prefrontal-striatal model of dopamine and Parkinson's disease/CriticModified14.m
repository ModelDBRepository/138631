% I think only SAC input is enough..I will check and might add PFC wts to critic unit
% do I have prediction at previous time..yes I think

Temp = 0;
for i=1:Num_SAC_Nodes
    Temp = Temp + SAC_Act(i)*Wts_SAC_Critic(i,1);
end
%Prediction Computing.
if(time == 1)
    Prediction(time) = 0;
    %keyboard
    %'ahmed'
else
    Prediction(time) = Temp;
end

%sig_S(Prediction);    % July
%Prediction = sig_S(Prediction);    % July
%Prediction = Prediction/20;    % July

% computing the TD error
if(time ==1)
    TDError(time)=Reward(time)+(DiscountFactor*Prediction(time)); %becasue Prediction(i-1)=0 in this case.
else
    TDError(time)=Reward(time)+(DiscountFactor*Prediction(time))-Prediction(time-1); % how about time 1
end

% Weight Update
if (time >= 2)
    for s=1:Num_SAC_Nodes
        %Wts_SAC_Critic(s)=Wts_SAC_Critic(s)+LR_Critic*TDError(time)*SAC_Act(s,time-1); % how about time 1
        Wts_SAC_Critic(s)=Wts_SAC_Critic(s)+LR_Critic*TDError(time)*SAC_Act_time(s,time-1); % how about time 1
    end
end

%Prediction = Prediction/20;    % July
%TDError =TDError/20;

Prediction_all(TrlNumTotal,:) = Prediction;
TDError_all(TrlNumTotal,:) = TDError;

