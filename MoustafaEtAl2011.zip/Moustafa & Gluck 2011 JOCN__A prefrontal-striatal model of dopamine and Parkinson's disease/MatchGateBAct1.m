% this is file is to see whether the model Gates A and make Act2 and 
GateBAct1=zeros (1, NumberOfTrials);

for i=1:NumberOfTrials
    if (IsBGatedGen (i) == 1 & WhatTrialAct1Made(i) == 1)
        GateBAct1 (i) = 1;
    end
end

GateBAct1