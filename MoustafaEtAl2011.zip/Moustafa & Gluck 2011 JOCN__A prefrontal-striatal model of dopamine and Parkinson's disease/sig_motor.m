% sig_T
function result = sig_motor(x)
%Gain_T = 1;
Gain_T = 0.1;     % DA reduction in T-matrisomes.   no action is made.
Gain_T = 0.2;
Gain_T = 0.5;
Gain_T = 1;           
%Gain = 0.4;   % no motor response; Gain in sig_D was 1.
%Bias = 0;   % I may add it later.
%Gain = 100000;  %This is to imitate linear units with Threshold = 0
result=1./(1+exp(-Gain_T*x));
