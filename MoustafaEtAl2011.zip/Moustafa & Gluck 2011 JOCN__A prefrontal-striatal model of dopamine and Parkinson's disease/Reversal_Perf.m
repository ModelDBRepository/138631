if (isequal(experiment_type,'Slots_Rev') & (PhaseNum == 2) & TrlNum ==1)  % this is first trial in second phase
    Wts_PFC_Motor = rand(Num_PFC_Nodes,Num_Motor_Nodes);
    Wts_SAC_PFC = rand(Num_SAC_Nodes,1); % because it is 1-1.
    % this was good for the model to change to a new dim
    % though it did not work all the time

    %Wts_PFC_Motor = rand(Num_PFC_Nodes,Num_Motor_Nodes);
    % this was good for the model to stick to a new dim
    % though it did not work all the time

end

if (isequal(experiment_type,'Crabs_Rev') & (PhaseNum == 2) & TrlNum ==1)  % this is first trial in second phase
    %Wts_PFC_Motor = rand(Num_PFC_Nodes,Num_Motor_Nodes);
    %Wts_SAC_PFC = rand(Num_SAC_Nodes,1); % because it is 1-1.


    Wts_PFC_Motor = rand(Num_PFC_Nodes,Num_Motor_Nodes);
    % this was good for the model to stick to a new dim
    % though it did not work all the time

end
%keyboard