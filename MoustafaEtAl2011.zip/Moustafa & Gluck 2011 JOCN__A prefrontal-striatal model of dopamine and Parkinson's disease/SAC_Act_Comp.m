%   X  Y  A B C.... C is another cue replacing US
% order is same as in Table 1, shohamy's paper
%          Candle    Fish     Boat     ctx     ctx
%          Lightbulb Butterfly Plane

if(isequal(experiment_type,'A+'))
    if (time == 1)
        SAC_Act = [0 0 0 0 0 0];
    else
        SAC_Act = [1 1 1 1 1 1];
        Correct_resp = 'B';
    end
elseif(isequal(experiment_type,'OneCue'))
    if (time == 1)
        SAC_Act = [0 0 0];
    else
        if (mod(TrlNum,NumCases) == 1)  % Input_1....10 is because of Num of trls is 10
            SAC_Act = Input_1;
            Correct_resp = 'A';
        elseif(mod(TrlNum,NumCases) == 0)
            SAC_Act = Input_2;
            Correct_resp = 'A';
        end
    end
elseif(isequal(experiment_type,'OneCue2'))
    if (time == 1)
        SAC_Act = [0 0 0];
    else
        if (mod(TrlNum,NumCases) == 1)  % Input_1....10 is because of Num of trls is 10
            SAC_Act = Input_1;
            Correct_resp = 'A';
        elseif(mod(TrlNum,NumCases) == 2)
            SAC_Act = Input_2;
            Correct_resp = 'A';  
        elseif(mod(TrlNum,NumCases) == 3)
            SAC_Act = Input_3;
            Correct_resp = 'A';
        elseif(mod(TrlNum,NumCases) == 0)
            SAC_Act = Input_4;
            Correct_resp = 'B';       
        end
    end
elseif(isequal(experiment_type,'Slots') | (isequal(experiment_type,'Slots_Rev') & (PhaseNum == 1))) % later I will randomize order presentation
    if (mod(TrlNum,NumCases) == 1)  % Input_1....10 is because of Num of trls is 10
        SAC_Act = Input_1;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 2)
        SAC_Act = Input_2;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 3)
        SAC_Act = Input_3;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 4)
        SAC_Act = Input_4;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 5)
        SAC_Act = Input_5;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 6)
        SAC_Act = Input_6;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 7)
        SAC_Act = Input_7;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 0)
        SAC_Act = Input_8;
        Correct_resp = 'B';
    end
elseif (isequal(experiment_type,'Slots_Rev') & (PhaseNum == 2))
    if (mod(TrlNum,NumCases) == 1)  % Input_1....10 is because of Num of trls is 10
        SAC_Act = Input_1;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 2)
        SAC_Act = Input_2;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 3)
        SAC_Act = Input_3;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 4)
        SAC_Act = Input_4;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 5)
        SAC_Act = Input_5;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 6)
        SAC_Act = Input_6;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 7)
        SAC_Act = Input_7;
        Correct_resp = 'A';       
    elseif(mod(TrlNum,NumCases) == 0)
        SAC_Act = Input_8;
        Correct_resp = 'A';
    end
    
    
elseif(isequal(experiment_type,'Crabs')|(isequal(experiment_type,'Crabs_Rev') & (PhaseNum == 1)))
    SAC_Act = [1 1 0 0 0 0];   % A is correct here. this is determinisitic. later I will do prob.
     Correct_resp = 'A';
elseif(isequal(experiment_type,'Crabs_Rev') & (PhaseNum == 2))
    SAC_Act = [1 1 0 0 0 0];   % A is correct here. this is determinisitic. later I will do prob.
     Correct_resp = 'B';
elseif (isequal(experiment_type,'WP'))
    if (mod(TrlNum,NumCases) == 1)  % Input_1....10 is because of Num of trls is 10
        SAC_Act = Input_1;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 2)
        SAC_Act = Input_2;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 3)
        SAC_Act = Input_3;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 4)
        SAC_Act = Input_4;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 5)
        SAC_Act = Input_5;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 6)
        SAC_Act = Input_6;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 7)
        SAC_Act = Input_7;
        Correct_resp = 'A';  
    elseif(mod(TrlNum,NumCases) == 8)
        SAC_Act = Input_8;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 9)
        SAC_Act = Input_9;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 10)
        SAC_Act = Input_10;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 11)
        SAC_Act = Input_11;
        Correct_resp = 'A';
    elseif(mod(TrlNum,NumCases) == 12)
        SAC_Act = Input_12;
        Correct_resp = 'B';
    elseif(mod(TrlNum,NumCases) == 13)
        SAC_Act = Input_13;
        Correct_resp = 'B'; 
    elseif(mod(TrlNum,NumCases) == 0)
        SAC_Act = Input_14;
        Correct_resp = 'B';
    end
end


SAC_Act = SAC_Act';
SAC_Act_time(:,time) = SAC_Act;

%keyboard

