% sig_S          *this is for the Critic.
function result = sig_S(x)
Gain_S = 1;    % see Initializations2
%Gain = 0.2; % testing the effect of DA reduction in the striatum. persveration
%Gain = 0.6;  % has no big effect
%Gain = 0.4;  % no big effect
%Bias = 0;   % I may add it later.
%Gain = 100000;  %This is to imitate linear units with Threshold = 0
Gain_S = 2;
Gain_S = 1.5;  % so so
%Gain_S = 1.8;  % so so
%Gain_S = 0.5;
%Bias = 2;
Bias = 0;
result=1./(1+exp((-Gain_S*x)+Bias));
